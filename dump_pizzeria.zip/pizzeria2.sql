-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mer. 27 juin 2018 à 12:04
-- Version du serveur :  10.1.30-MariaDB
-- Version de PHP :  7.2.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `pizzeria2`
--

-- --------------------------------------------------------

--
-- Structure de la table `client`
--

CREATE TABLE `client` (
  `idclient` int(11) NOT NULL,
  `nom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `email` varchar(1000) COLLATE utf8_bin NOT NULL,
  `num_rue` int(11) NOT NULL,
  `localisation` varchar(1000) COLLATE utf8_bin NOT NULL,
  `commune` varchar(1000) COLLATE utf8_bin NOT NULL,
  `code_postal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `client`
--

INSERT INTO `client` (`idclient`, `nom`, `prenom`, `email`, `num_rue`, `localisation`, `commune`, `code_postal`) VALUES
(1, 'Skywalker', 'Luke', 'lukeskywalker@pizza.com', 8, 'Rue la force est en toi', 'Fort-de-France', 97200),
(2, 'Skywalker', 'Leia', 'leiaskywalker@pizza.com', 9, 'Rue la force est en toi', 'Fort-de-France', 97200),
(3, 'Stark', 'Tony', 'tonystark@pizza.com', 12, 'Rue des Avengers', 'Fort-de-France', 97200),
(4, 'Rodger', 'Steeve', 'steeverodger@pizza.com', 123, 'Bld du bouclier', 'Fort-de-France', 97200),
(5, 'Parker', 'Peter', 'peterparker@pizza.com', 33, 'Allee des araignees', 'Fort-de-France', 97200),
(6, 'Snow', 'Jon', 'jonsnow@pizza.com', 13, 'Rue du Mur', 'Fort-de-France', 97200),
(7, 'Lannister', 'Tyrion', 'tyrionlannister@pizza.com', 54, 'Chemin des nains', 'Fort-de-France', 97200),
(8, 'Stark', 'Sansa', 'sansastark@pizza.com', 123, 'Rue de Winterfell', 'Fort-de-France', 97200),
(9, 'Tarly', 'Samwell', 'samwelltarly@pizza.com', 15, 'Rue du Mur', 'Fort-de-France', 97200),
(10, 'Stark', 'Arya', 'aryastark@pizza.com', 125, 'Rue de Winterfell', 'Fort-de-France', 97200);

-- --------------------------------------------------------

--
-- Structure de la table `commande`
--

CREATE TABLE `commande` (
  `num_commande` int(11) NOT NULL,
  `montant` double NOT NULL,
  `quantite` int(11) NOT NULL,
  `idclient` int(11) NOT NULL,
  `idets` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `commande`
--

INSERT INTO `commande` (`num_commande`, `montant`, `quantite`, `idclient`, `idets`) VALUES
(12356, 45, 4, 1, 2),
(254414, 30, 1, 6, 1),
(332214, 50, 2, 10, 1);

-- --------------------------------------------------------

--
-- Structure de la table `ets`
--

CREATE TABLE `ets` (
  `idets` int(11) NOT NULL,
  `num_rue` int(11) NOT NULL,
  `rue` varchar(1000) COLLATE utf8_bin NOT NULL,
  `commune` varchar(1000) COLLATE utf8_bin NOT NULL,
  `code_postal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `ets`
--

INSERT INTO `ets` (`idets`, `num_rue`, `rue`, `commune`, `code_postal`) VALUES
(1, 23, 'Rue de la Mozarella', 'Fort-de-France', 97200),
(2, 145, 'Boulevard du chorizo', 'Fort-de-France', 97200);

-- --------------------------------------------------------

--
-- Structure de la table `ingrdient`
--

CREATE TABLE `ingrdient` (
  `idpizza` int(11) NOT NULL,
  `idproduit` int(11) NOT NULL,
  `quantite_necessaire` varchar(1000) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `ingrdient`
--

INSERT INTO `ingrdient` (`idpizza`, `idproduit`, `quantite_necessaire`) VALUES
(1, 1, ''),
(1, 5, ''),
(1, 6, ''),
(1, 7, ''),
(2, 1, ''),
(2, 2, ''),
(2, 5, ''),
(2, 6, ''),
(2, 7, ''),
(3, 1, ''),
(3, 2, ''),
(3, 3, ''),
(3, 5, ''),
(3, 6, ''),
(3, 9, ''),
(4, 1, ''),
(4, 6, ''),
(4, 14, ''),
(4, 18, '');

-- --------------------------------------------------------

--
-- Structure de la table `ligne_commande`
--

CREATE TABLE `ligne_commande` (
  `idchoix` int(11) NOT NULL,
  `quantite` int(11) NOT NULL,
  `prix` double NOT NULL,
  `num_commande` int(11) NOT NULL,
  `idpizza` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `ligne_commande`
--

INSERT INTO `ligne_commande` (`idchoix`, `quantite`, `prix`, `num_commande`, `idpizza`) VALUES
(1, 2, 20, 332214, 8),
(2, 1, 24, 12356, 2),
(3, 3, 16, 12356, 1),
(4, 1, 30, 254414, 5);

-- --------------------------------------------------------

--
-- Structure de la table `livreur`
--

CREATE TABLE `livreur` (
  `idlivreur` int(11) NOT NULL,
  `nom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `idets` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `livreur`
--

INSERT INTO `livreur` (`idlivreur`, `nom`, `prenom`, `idets`) VALUES
(1, 'Santini', 'Mario', 1),
(2, 'Garibaldi', 'Luigi', 2);

-- --------------------------------------------------------

--
-- Structure de la table `pizza`
--

CREATE TABLE `pizza` (
  `idpizza` int(11) NOT NULL,
  `nom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `PHT` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `pizza`
--

INSERT INTO `pizza` (`idpizza`, `nom`, `PHT`) VALUES
(1, 'Margharita', 13),
(2, 'Reine', 12),
(3, 'Canibale', 22),
(4, 'Scandinave', 21),
(5, 'Montagnarde', 25),
(6, '4 Fromages', 17),
(7, 'Hawaienne', 19),
(8, 'Sicilienne', 20),
(9, 'Napolitaine', 29),
(10, 'Végétarienne', 25);

-- --------------------------------------------------------

--
-- Structure de la table `pizzaiolo`
--

CREATE TABLE `pizzaiolo` (
  `idpizzaiolo` int(11) NOT NULL,
  `nom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `prenom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `idets` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `pizzaiolo`
--

INSERT INTO `pizzaiolo` (`idpizzaiolo`, `nom`, `prenom`, `idets`) VALUES
(1, 'Bambino', 'Pepe', 1),
(2, 'Al Capone', 'Gianni', 2);

-- --------------------------------------------------------

--
-- Structure de la table `stock`
--

CREATE TABLE `stock` (
  `idproduit` int(11) NOT NULL,
  `nom` varchar(1000) COLLATE utf8_bin NOT NULL,
  `quantit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Déchargement des données de la table `stock`
--

INSERT INTO `stock` (`idproduit`, `nom`, `quantit`) VALUES
(1, 'Mozzarella', 500),
(2, 'Jambon', 500),
(3, 'Lardon', 500),
(4, 'Emmental', 500),
(5, 'Tomate', 500),
(6, 'Farine', 4000),
(7, 'Champignon', 250),
(8, 'Poivron', 300),
(9, 'Merguez', 1000),
(10, 'Chorizo', 1000),
(11, 'Anchois', 500),
(12, 'Piments', 100),
(13, 'Ananas', 1000),
(14, 'Crème fraîche', 2000),
(15, 'Pommes de terre', 5000),
(16, 'Coeur d artichaut', 1500),
(17, 'Brocolis', 3000),
(18, 'Saumon', 4000),
(19, 'Raclette', 2000);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`idclient`);

--
-- Index pour la table `commande`
--
ALTER TABLE `commande`
  ADD PRIMARY KEY (`num_commande`),
  ADD KEY `ets_commande_fk` (`idets`),
  ADD KEY `client_commande_fk` (`idclient`);

--
-- Index pour la table `ets`
--
ALTER TABLE `ets`
  ADD PRIMARY KEY (`idets`);

--
-- Index pour la table `ingrdient`
--
ALTER TABLE `ingrdient`
  ADD PRIMARY KEY (`idpizza`,`idproduit`),
  ADD KEY `stock_ingrdient_fk` (`idproduit`);

--
-- Index pour la table `ligne_commande`
--
ALTER TABLE `ligne_commande`
  ADD PRIMARY KEY (`idchoix`),
  ADD KEY `pizza_ligne_commande_fk` (`idpizza`),
  ADD KEY `commande_ligne_commande_fk` (`num_commande`);

--
-- Index pour la table `livreur`
--
ALTER TABLE `livreur`
  ADD PRIMARY KEY (`idlivreur`),
  ADD KEY `ets_livreur_fk` (`idets`);

--
-- Index pour la table `pizza`
--
ALTER TABLE `pizza`
  ADD PRIMARY KEY (`idpizza`);

--
-- Index pour la table `pizzaiolo`
--
ALTER TABLE `pizzaiolo`
  ADD PRIMARY KEY (`idpizzaiolo`),
  ADD KEY `ets_pizzaiolo_fk` (`idets`);

--
-- Index pour la table `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`idproduit`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `ligne_commande`
--
ALTER TABLE `ligne_commande`
  MODIFY `idchoix` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `commande`
--
ALTER TABLE `commande`
  ADD CONSTRAINT `client_commande_fk` FOREIGN KEY (`idclient`) REFERENCES `client` (`idclient`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `ets_commande_fk` FOREIGN KEY (`idets`) REFERENCES `ets` (`idets`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `ingrdient`
--
ALTER TABLE `ingrdient`
  ADD CONSTRAINT `pizza_ingrdient_fk` FOREIGN KEY (`idpizza`) REFERENCES `pizza` (`idpizza`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `stock_ingrdient_fk` FOREIGN KEY (`idproduit`) REFERENCES `stock` (`idproduit`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `ligne_commande`
--
ALTER TABLE `ligne_commande`
  ADD CONSTRAINT `commande_ligne_commande_fk` FOREIGN KEY (`num_commande`) REFERENCES `commande` (`num_commande`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `pizza_ligne_commande_fk` FOREIGN KEY (`idpizza`) REFERENCES `pizza` (`idpizza`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `livreur`
--
ALTER TABLE `livreur`
  ADD CONSTRAINT `ets_livreur_fk` FOREIGN KEY (`idets`) REFERENCES `ets` (`idets`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Contraintes pour la table `pizzaiolo`
--
ALTER TABLE `pizzaiolo`
  ADD CONSTRAINT `ets_pizzaiolo_fk` FOREIGN KEY (`idets`) REFERENCES `ets` (`idets`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
